Booking form should be placed in this directory
Image files used for background, etc should be placed in this directory

help.png is converted from the public domain image at http://openclipart.org/media/files/zeratul/2963
