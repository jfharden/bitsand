This is Bitsand, an online booking system for use with Lorien Trust Rules v3 (www.lorientrust.com).

Report bugs, request features, etc via the Google Code page: http://code.google.com/p/bitsand/issues/list

If you need help, contact Russ Phillips on russ@phillipsuk.org
